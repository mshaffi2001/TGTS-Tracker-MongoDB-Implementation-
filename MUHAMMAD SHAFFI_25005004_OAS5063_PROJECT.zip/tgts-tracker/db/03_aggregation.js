use tgts_tracker

// Pipeline: for each account, show dashboard field labels + count of alert recipients
db.customers.aggregate([
  // Step 1: Join with dashboards
  {
    $lookup: {
      from: "dashboards",
      localField: "_id",
      foreignField: "_id",
      as: "dashboard"
    }
  },
  // Step 2: Join with alerts
  {
    $lookup: {
      from: "alerts",
      localField: "_id",
      foreignField: "_id",
      as: "alert"
    }
  },
  // Step 3: Flatten the arrays (each account has at most 1 dashboard/alert)
  { $unwind: { path: "$dashboard", preserveNullAndEmptyArrays: true } },
  { $unwind: { path: "$alert",     preserveNullAndEmptyArrays: true } },
  // Step 4: Project the output shape
  {
    $project: {
      _id: 1,
      customerName:   "$name",
      dashboardFields: "$dashboard.fields",
      alertCount: {
        $cond: {
          if:   { $isArray: "$alert.recipients" },
          then: { $size: "$alert.recipients" },
          else: 0
        }
      }
    }
  }
])