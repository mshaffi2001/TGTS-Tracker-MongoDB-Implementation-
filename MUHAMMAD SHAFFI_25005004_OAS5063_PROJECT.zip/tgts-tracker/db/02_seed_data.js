use tgts_tracker

// Customers
db.customers.insertMany([
  { _id: "ACC-1001", name: "Muhammad Shaffi", currency: "MYR" },
  { _id: "ACC-1002", name: "Donald Trump",  currency: "USD" },
  { _id: "ACC-1003", name: "Lawrence Wong",    currency: "SGD" }
])

// Dashboards (must pass schema validation)
db.dashboards.insertMany([
  { _id: "ACC-1001", fields: ["SHIPMENT_STATUS", "ETA", "ORIGIN"] },
  { _id: "ACC-1002", fields: ["SHIPMENT_STATUS", "DESTINATION", "CARRIER"] },
  { _id: "ACC-1003", fields: ["ETA", "WEIGHT"] }
])

// Alerts — ACC-1001 expires SOON (for TTL demo), ACC-1002 expires later
db.alerts.insertMany([
  {
    _id: "ACC-1001",
    recipients: ["mshaffi@email.com", "+60111111111"],
    expiresAt: new Date(Date.now() + 60 * 1000)  // expires in 60 seconds!
  },
  {
    _id: "ACC-1002",
    recipients: ["DonaldT@email.com"],
    expiresAt: new Date("2027-01-01T00:00:00Z")
  },
  {
    _id: "ACC-1003",
    recipients: ["LWong@email.com", "LauWong@yahoo.com"]
    // No expiresAt = never expires (TTL index ignores null)
  }
])

// UI Configs
db.ui_configs.insertMany([
  { _id: "ACC-1001", fontName: "Roboto",    fontSize: 14, colorScheme: "dark",  preferredLanguage: "Malay" },
  { _id: "ACC-1002", fontName: "Open Sans", fontSize: 16, colorScheme: "light", preferredLanguage: "English" },
  { _id: "ACC-1003", fontName: "Lato",      fontSize: 12, colorScheme: "dark",  preferredLanguage: "English" }
])

print("Seed data inserted")