use tgts_tracker

// ── 1. customers (simple, no special validation needed) ──────────────────
db.createCollection("customers")

// ── 2. dashboards (JSON Schema validation on fields array) ───────────────
db.createCollection("dashboards", {
  validator: {
    $jsonSchema: {
      bsonType: "object",
      required: ["_id", "fields"],
      properties: {
        _id: { bsonType: "string" },
        fields: {
          bsonType: "array",
          description: "Must be array of allowed field codes",
          items: {
            bsonType: "string",
            enum: [
              "SHIPMENT_STATUS",
              "ETA",
              "ORIGIN",
              "DESTINATION",
              "CARRIER",
              "WEIGHT"
            ]
          }
        }
      }
    }
  },
  validationAction: "error"   // Rejects invalid inserts — important for marks!
})

// ── 3. alerts ────────────────────────────────────────────────────────────
db.createCollection("alerts")

// ── 4. ui_configs ────────────────────────────────────────────────────────
db.createCollection("ui_configs")

// ── INDEXES ──────────────────────────────────────────────────────────────
// TTL index on alerts (mandatory)
db.alerts.createIndex(
  { expiresAt: 1 },
  { expireAfterSeconds: 0 }   // Expires AT the expiresAt timestamp exactly
)

// Point-read indexes (_id is auto-indexed, but we document compound safety)
db.customers.createIndex({ _id: 1 })
db.dashboards.createIndex({ _id: 1 })
db.alerts.createIndex({ _id: 1 })
db.ui_configs.createIndex({ _id: 1 })

print("Collections and indexes created successfully")