const { MongoClient } = require("mongodb");
require("dotenv").config();

let db;
async function connect() {
  if (db) return db;
  const client = new MongoClient(process.env.MONGO_URI);
  await client.connect();
  db = client.db("tgts_tracker");
  console.log("Connected to MongoDB");
  return db;
}
module.exports = connect;