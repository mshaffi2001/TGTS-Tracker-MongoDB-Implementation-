const express = require("express");
const router = express.Router();
const connect = require("../db");

// GET /profile/:id  — merges all 4 collections for one account
router.get("/:id", async (req, res) => {
  const db = await connect();
  const id = req.params.id;

  const [customer, dashboard, alert, uiConfig] = await Promise.all([
    db.collection("customers").findOne({ _id: id }),
    db.collection("dashboards").findOne({ _id: id }),
    db.collection("alerts").findOne({ _id: id }),
    db.collection("ui_configs").findOne({ _id: id })
  ]);

  if (!customer) {
    return res.status(404).json({ error: `Account ${id} not found` });
  }

  res.json({
    accountNumber: id,
    customer,
    dashboard:  dashboard  || null,
    alert:      alert      || null,
    uiConfig:   uiConfig   || null
  });
});

// POST /profile/:id/customer — Create/Update customer
router.post("/:id/customer", async (req, res) => {
  const db = await connect();
  const result = await db.collection("customers").updateOne(
    { _id: req.params.id },
    { $set: { ...req.body, _id: req.params.id } },
    { upsert: true }
  );
  res.json({ success: true, result });
});

// POST /profile/:id/dashboard
router.post("/:id/dashboard", async (req, res) => {
  const db = await connect();
  try {
    const result = await db.collection("dashboards").updateOne(
      { _id: req.params.id },
      { $set: { ...req.body, _id: req.params.id } },
      { upsert: true }
    );
    res.json({ success: true, result });
  } catch (err) {
    // Catches JSON Schema validation errors
    res.status(400).json({ error: err.message });
  }
});

// POST /profile/:id/alert
router.post("/:id/alert", async (req, res) => {
  const db = await connect();
  const body = { ...req.body, _id: req.params.id };
  if (body.expiresAt) body.expiresAt = new Date(body.expiresAt);
  const result = await db.collection("alerts").updateOne(
    { _id: req.params.id },
    { $set: body },
    { upsert: true }
  );
  res.json({ success: true, result });
});

// POST /profile/:id/ui
router.post("/:id/ui", async (req, res) => {
  const db = await connect();
  const result = await db.collection("ui_configs").updateOne(
    { _id: req.params.id },
    { $set: { ...req.body, _id: req.params.id } },
    { upsert: true }
  );
  res.json({ success: true, result });
});

module.exports = router;