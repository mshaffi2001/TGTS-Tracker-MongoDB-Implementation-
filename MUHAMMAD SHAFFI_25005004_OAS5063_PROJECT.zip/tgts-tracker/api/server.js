const express = require("express");
require("dotenv").config();

const app = express();
app.use(express.json());
app.use("/profile", require("./routes/profile"));

app.get("/health", (_, res) => res.json({ status: "ok" }));

app.listen(process.env.PORT, () => {
  console.log(`TGTS API running on port ${process.env.PORT}`);
});